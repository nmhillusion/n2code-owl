package exercise2;

/**
 * created by: nmhillusion
 * <p>
 * created date: 2024-09-08
 */
public interface OutfitInterface {

    String wear();

}
