package exercise2.quan_ao;

/**
 * created by: nmhillusion
 * <p>
 * created date: 2024-09-08
 */


public class Vay extends QuanAoAbstract {
    @Override
    protected String info() {
        return "Vay";
    }
}
