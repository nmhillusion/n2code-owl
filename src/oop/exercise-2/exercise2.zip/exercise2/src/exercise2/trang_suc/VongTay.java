package exercise2.trang_suc;

/**
 * created by: nmhillusion
 * <p>
 * created date: 2024-10-30
 */
public class VongTay extends TrangSucAbstract {
    @Override
    protected String getName() {
        return "Vong Tay";
    }
}
